import React, { useMemo } from "react";

/** Purely decorative, animated blurred gradient blobs + drifting particles. */
function BackgroundFx() {
  const particles = useMemo(
    () =>
      Array.from({ length: 18 }, (_, i) => ({
        id: i,
        left: Math.round(Math.random() * 100),
        delay: (Math.random() * 14).toFixed(1),
        duration: (10 + Math.random() * 10).toFixed(1),
      })),
    []
  );

  return (
    <div className="bg-fx" aria-hidden="true">
      <span className="blob blob-1" />
      <span className="blob blob-2" />
      <span className="blob blob-3" />
      <div className="bg-grid" />
      <div className="particles">
        {particles.map((p) => (
          <span
            key={p.id}
            className="particle"
            style={{
              left: `${p.left}%`,
              bottom: "-10px",
              animationDelay: `${p.delay}s`,
              animationDuration: `${p.duration}s`,
            }}
          />
        ))}
      </div>
    </div>
  );
}

export default BackgroundFx;
