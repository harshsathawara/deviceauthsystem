import React, { useEffect, useState } from "react";
import { TimerReset } from "lucide-react";

function formatRemaining(ms) {
  if (ms <= 0) return "0:00";
  const totalSec = Math.floor(ms / 1000);
  const h = Math.floor(totalSec / 3600);
  const m = Math.floor((totalSec % 3600) / 60);
  const s = totalSec % 60;
  const mm = h > 0 ? String(m).padStart(2, "0") : m;
  const ss = String(s).padStart(2, "0");
  return h > 0 ? `${h}:${mm}:${ss}` : `${mm}:${ss}`;
}

/** Shows a live countdown until expiresAt (epoch ms) and calls onExpire once. */
function SessionCountdown({ expiresAt, onExpire }) {
  const [remaining, setRemaining] = useState(expiresAt - Date.now());

  useEffect(() => {
    const id = window.setInterval(() => {
      setRemaining((prevRemaining) => {
        const next = expiresAt - Date.now();
        if (next <= 0 && prevRemaining > 0) {
          onExpire && onExpire();
        }
        return next;
      });
    }, 1000);
    return () => window.clearInterval(id);
  }, [expiresAt, onExpire]);

  return (
    <span className="session-chip">
      <TimerReset size={13} />
      Session expires in {formatRemaining(remaining)}
    </span>
  );
}

export default SessionCountdown;
