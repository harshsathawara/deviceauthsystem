import React, { useCallback, useRef, useState } from "react";
import { CheckCircle2, XCircle, Info } from "lucide-react";

const ICONS = { success: CheckCircle2, error: XCircle, info: Info };

export function useToasts() {
  const [toasts, setToasts] = useState([]);
  const idRef = useRef(0);

  const dismissToast = useCallback((id) => {
    setToasts((t) => t.filter((toast) => toast.id !== id));
  }, []);

  const showToast = useCallback(
    (message, type = "success", duration = 2800) => {
      const id = ++idRef.current;
      setToasts((t) => [...t, { id, message, type }]);
      window.setTimeout(() => dismissToast(id), duration);
    },
    [dismissToast]
  );

  return { toasts, showToast, dismissToast };
}

export function ToastContainer({ toasts, dismissToast }) {
  return (
    <div className="toast-stack">
      {toasts.map((t) => {
        const Icon = ICONS[t.type] || Info;
        return (
          <div
            key={t.id}
            className={`toast toast-${t.type}`}
            onClick={() => dismissToast(t.id)}
          >
            <Icon size={16} />
            <span>{t.message}</span>
          </div>
        );
      })}
    </div>
  );
}
