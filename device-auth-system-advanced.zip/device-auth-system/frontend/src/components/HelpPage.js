import React from "react";
import {
  Wifi,
  ShieldCheck,
  KeyRound,
  Fingerprint,
  Network,
  Lock,
  Server,
  Laptop,
  ArrowRight,
  Zap,
  Building2,
  Home,
  Gauge,
  CheckCircle2,
} from "lucide-react";

const steps = [
  {
    icon: Laptop,
    title: "Device connects",
    text:
      "You open the app. No username or account picker — the page immediately asks the server who you are.",
  },
  {
    icon: Network,
    title: "Server reads your IP",
    text:
      "The backend pulls the caller's IP straight off the HTTP request (honoring X-Forwarded-For behind a proxy).",
  },
  {
    icon: Wifi,
    title: "ARP lookup for MAC",
    text:
      "On the same LAN, the server checks its ARP table to resolve that IP into a hardware MAC address.",
  },
  {
    icon: Fingerprint,
    title: "Identity assigned",
    text:
      "MAC found → that's your identifier. Not on the LAN? It gracefully falls back to IP. Either way, it's set server-side — never trusted from the browser.",
  },
  {
    icon: KeyRound,
    title: "Password + JWT",
    text:
      "You just set/confirm a password. On success the server signs a JWT bound to that identifier for every future request.",
  },
];

const useCases = [
  {
    icon: Building2,
    title: "Office kiosks & intranet apps",
    text:
      "Shared floor terminals where you want 'this specific machine' logged in — no shared logins passed around on sticky notes.",
  },
  {
    icon: Home,
    title: "Home lab / self-hosted tools",
    text:
      "Dashboards on your own network where typing a username every time is friction you don't need.",
  },
  {
    icon: Gauge,
    title: "Lightweight device tracking",
    text:
      "Know exactly which physical machine an account maps to — useful for audits, support, and access reviews.",
  },
  {
    icon: Zap,
    title: "Frictionless demos & POCs",
    text:
      "Spin up a login flow with zero manual username entry — great for internal tools and quick prototypes.",
  },
];

const security = [
  { icon: Lock, label: "BCrypt password hashing" },
  { icon: KeyRound, label: "Stateless JWT sessions" },
  { icon: ShieldCheck, label: "5-attempt login lockout" },
  { icon: Server, label: "Identity resolved server-side only" },
];

function HelpPage({ onBack }) {
  return (
    <div className="help-page fade-in">
      <section className="help-hero">
        <div className="hero-illustration" aria-hidden="true">
          <svg viewBox="0 0 200 160" className="hero-svg">
            <defs>
              <linearGradient id="heroGrad" x1="0" y1="0" x2="1" y2="1">
                <stop offset="0%" stopColor="#6366f1" />
                <stop offset="100%" stopColor="#22d3ee" />
              </linearGradient>
            </defs>
            <circle cx="100" cy="70" r="18" className="hero-ring hero-ring-1" />
            <circle cx="100" cy="70" r="34" className="hero-ring hero-ring-2" />
            <circle cx="100" cy="70" r="50" className="hero-ring hero-ring-3" />
            <rect
              x="70"
              y="52"
              width="60"
              height="38"
              rx="6"
              fill="url(#heroGrad)"
              className="hero-device"
            />
            <rect x="78" y="60" width="44" height="22" rx="2" fill="#0f172a" opacity="0.35" />
            <circle cx="100" cy="70" r="5" fill="#fff" className="hero-pulse-dot" />
          </svg>
        </div>
        <div className="help-hero-badge">
          <CheckCircle2 size={14} />
          How it works
        </div>
        <h1 className="help-hero-title">
          Login that <span className="gradient-text">knows your device</span>
          <br />
          before you type a thing
        </h1>
        <p className="help-hero-sub">
          No usernames to remember. The server figures out who's asking —
          from your MAC address on a local network, or your IP address
          anywhere else — and you just set a password on top of it.
        </p>
      </section>

      <section className="help-section">
        <h2 className="help-section-title">The flow, step by step</h2>
        <div className="steps-timeline">
          {steps.map((step, i) => {
            const Icon = step.icon;
            return (
              <div
                className="step-item"
                key={step.title}
                style={{ animationDelay: `${i * 0.12}s` }}
              >
                <div className="step-icon-wrap">
                  <Icon size={22} />
                  <span className="step-number">{i + 1}</span>
                </div>
                <div className="step-body">
                  <h3>{step.title}</h3>
                  <p>{step.text}</p>
                </div>
                {i < steps.length - 1 && (
                  <div className="step-connector">
                    <ArrowRight size={16} />
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </section>

      <section className="help-section">
        <h2 className="help-section-title">Where this actually helps</h2>
        <div className="usecase-grid">
          {useCases.map((uc, i) => {
            const Icon = uc.icon;
            return (
              <div
                className="usecase-card"
                key={uc.title}
                style={{ animationDelay: `${i * 0.08}s` }}
              >
                <div className="usecase-icon">
                  <Icon size={20} />
                </div>
                <h3>{uc.title}</h3>
                <p>{uc.text}</p>
              </div>
            );
          })}
        </div>
      </section>

      <section className="help-section">
        <h2 className="help-section-title">Direct fetch, explained</h2>
        <div className="direct-explain">
          <div className="direct-explain-col">
            <div className="direct-explain-icon ip">
              <Network size={18} />
            </div>
            <h3>Fetch IP</h3>
            <p>
              Always works. Reads the raw client IP straight from the request
              — over LAN, Wi-Fi, or the open internet.
            </p>
          </div>
          <div className="direct-explain-col">
            <div className="direct-explain-icon mac">
              <Wifi size={18} />
            </div>
            <h3>Fetch MAC</h3>
            <p>
              Only works when the server shares a network segment with you.
              It queries the ARP table directly — off-LAN it honestly tells
              you it can't resolve, instead of guessing.
            </p>
          </div>
        </div>
      </section>

      <section className="help-section">
        <h2 className="help-section-title">Built-in security</h2>
        <div className="security-badges">
          {security.map((s) => {
            const Icon = s.icon;
            return (
              <div className="security-badge" key={s.label}>
                <Icon size={16} />
                {s.label}
              </div>
            );
          })}
        </div>
      </section>

      <div className="help-cta">
        <button className="btn btn-primary help-cta-btn" onClick={onBack}>
          Back to app
        </button>
      </div>
    </div>
  );
}

export default HelpPage;
