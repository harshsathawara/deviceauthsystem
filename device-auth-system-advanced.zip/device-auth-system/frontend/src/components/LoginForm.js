import React, { useState } from "react";
import { Eye, EyeOff } from "lucide-react";
import { loginUser } from "../api";

function LoginForm({ onSuccess, onToast }) {
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setSubmitting(true);
    try {
      const res = await loginUser(password);
      onToast && onToast("Login successful", "success");
      onSuccess(res.data);
    } catch (err) {
      const msg = err.response?.data?.error || "Login failed";
      setError(msg);
      onToast && onToast(msg, "error");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <label className="field-label">Password</label>
      <div className="password-row">
        <input
          type={showPassword ? "text" : "password"}
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
          minLength={4}
        />
        <button
          type="button"
          className="show-hide-btn"
          onClick={() => setShowPassword((s) => !s)}
          tabIndex={-1}
        >
          {showPassword ? <EyeOff size={14} /> : <Eye size={14} />}
        </button>
      </div>
      {error && <p className="error">{error}</p>}
      <button className="btn btn-primary" type="submit" disabled={submitting}>
        {submitting ? "Logging in..." : "Log In"}
      </button>
    </form>
  );
}

export default LoginForm;
