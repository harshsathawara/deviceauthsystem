import React from "react";

function Footer() {
  return (
    <footer className="app-footer">
      <span>© {new Date().getFullYear()} Device Auth System</span>
      <span className="dot-sep">•</span>
      <span>
        Build by <strong>Harsh Sathawara</strong>
      </span>
    </footer>
  );
}

export default Footer;
