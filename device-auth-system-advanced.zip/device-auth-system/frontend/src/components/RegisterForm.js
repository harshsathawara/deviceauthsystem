import React, { useState } from "react";
import { Eye, EyeOff } from "lucide-react";
import { registerUser } from "../api";

function passwordStrength(pw) {
  if (!pw) return { label: "", pct: 0 };
  let score = 0;
  if (pw.length >= 6) score++;
  if (pw.length >= 10) score++;
  if (/[A-Z]/.test(pw) && /[a-z]/.test(pw)) score++;
  if (/[0-9]/.test(pw)) score++;
  if (/[^A-Za-z0-9]/.test(pw)) score++;
  const levels = [
    { label: "Very weak", pct: 20 },
    { label: "Weak", pct: 40 },
    { label: "Okay", pct: 60 },
    { label: "Good", pct: 80 },
    { label: "Strong", pct: 100 },
  ];
  return levels[Math.min(score, levels.length - 1)];
}

function RegisterForm({ onSuccess, onToast }) {
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);

  const strength = passwordStrength(password);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");

    if (password !== confirmPassword) {
      setError("Passwords do not match");
      return;
    }

    setSubmitting(true);
    try {
      const res = await registerUser(password);
      onToast && onToast("Device registered", "success");
      onSuccess(res.data);
    } catch (err) {
      const msg = err.response?.data?.error || "Registration failed";
      setError(msg);
      onToast && onToast(msg, "error");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <label className="field-label">Password</label>
      <div className="password-row">
        <input
          type={showPassword ? "text" : "password"}
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
          minLength={4}
        />
        <button
          type="button"
          className="show-hide-btn"
          onClick={() => setShowPassword((s) => !s)}
          tabIndex={-1}
        >
          {showPassword ? <EyeOff size={14} /> : <Eye size={14} />}
        </button>
      </div>
      {password && (
        <div className="strength-bar">
          <div
            className="strength-fill"
            style={{ width: `${strength.pct}%` }}
          />
          <span className="strength-label">{strength.label}</span>
        </div>
      )}

      <label className="field-label">Confirm Password</label>
      <input
        type={showPassword ? "text" : "password"}
        value={confirmPassword}
        onChange={(e) => setConfirmPassword(e.target.value)}
        required
        minLength={4}
      />
      {error && <p className="error">{error}</p>}
      <button className="btn btn-primary" type="submit" disabled={submitting}>
        {submitting ? "Registering..." : "Register"}
      </button>
    </form>
  );
}

export default RegisterForm;
