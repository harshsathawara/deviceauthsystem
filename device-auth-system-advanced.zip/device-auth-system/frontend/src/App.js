import React, { useEffect, useState, useCallback } from "react";
import {
  ShieldCheck,
  HelpCircle,
  Radar,
  LogOut,
  Sun,
  Moon,
  Copy,
  Check,
} from "lucide-react";
import { getDeviceIdentity, fetchIpDirect, fetchMacDirect } from "./api";
import LoginForm from "./components/LoginForm";
import RegisterForm from "./components/RegisterForm";
import Footer from "./components/Footer";
import HelpPage from "./components/HelpPage";
import BackgroundFx from "./components/BackgroundFx";
import SessionCountdown from "./components/SessionCountdown";
import { useToasts, ToastContainer } from "./components/Toast";

function CopyButton({ value, onToast }) {
  const [copied, setCopied] = useState(false);
  if (!value) return null;

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(value);
      setCopied(true);
      onToast && onToast("Copied to clipboard", "info", 1500);
      window.setTimeout(() => setCopied(false), 1200);
    } catch {
      onToast && onToast("Could not copy", "error");
    }
  };

  return (
    <button
      type="button"
      className="copy-btn"
      onClick={handleCopy}
      title="Copy to clipboard"
    >
      {copied ? <Check size={13} /> : <Copy size={13} />}
    </button>
  );
}

function App() {
  const [identifier, setIdentifier] = useState("");
  const [identifierType, setIdentifierType] = useState("");
  const [hostname, setHostname] = useState("");
  const [loadingDevice, setLoadingDevice] = useState(true);
  const [deviceError, setDeviceError] = useState("");
  const [mode, setMode] = useState("login"); // "login" | "register"
  const [token, setToken] = useState("");
  const [expiresAt, setExpiresAt] = useState(null);
  const [view, setView] = useState("auth"); // "auth" | "help"
  const [theme, setTheme] = useState("dark"); // "dark" | "light"

  const { toasts, showToast, dismissToast } = useToasts();

  const [showDirectFetch, setShowDirectFetch] = useState(false);
  const [directIp, setDirectIp] = useState(null);
  const [directMac, setDirectMac] = useState(null);
  const [directIpLoading, setDirectIpLoading] = useState(false);
  const [directMacLoading, setDirectMacLoading] = useState(false);
  const [directMacError, setDirectMacError] = useState("");

  useEffect(() => {
    document.documentElement.setAttribute("data-theme", theme);
  }, [theme]);

  const loadIdentity = () => {
    setLoadingDevice(true);
    setDeviceError("");
    getDeviceIdentity()
      .then((res) => {
        setIdentifier(res.data.identifier);
        setIdentifierType(res.data.identifierType);
        setHostname(res.data.hostname || "");
      })
      .catch(() => {
        setDeviceError("Could not detect device identity. Is the backend running?");
      })
      .finally(() => setLoadingDevice(false));
  };

  useEffect(() => {
    loadIdentity();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleFetchIp = async () => {
    setDirectIpLoading(true);
    try {
      const res = await fetchIpDirect();
      setDirectIp(res.data.ipAddress);
    } catch {
      setDirectIp(null);
      showToast("Could not fetch IP", "error");
    } finally {
      setDirectIpLoading(false);
    }
  };

  const handleFetchMac = async () => {
    setDirectMacLoading(true);
    setDirectMacError("");
    setDirectMac(null);
    try {
      const res = await fetchMacDirect();
      setDirectMac(res.data.macAddress);
    } catch (err) {
      const msg = err.response?.data?.error || "MAC address could not be resolved.";
      setDirectMacError(msg);
      showToast(msg, "error", 3500);
    } finally {
      setDirectMacLoading(false);
    }
  };

  const handleAuthSuccess = (data) => {
    setToken(data.token);
    setExpiresAt(data.expiresAt || null);
    setIdentifier(data.identifier);
    setIdentifierType(data.identifierType);
  };

  const handleExpire = useCallback(() => {
    setToken("");
    showToast("Session expired — please log in again", "info", 3500);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const TopBar = ({ showHelpToggle = true }) => (
    <div className="topbar">
      <div className="brand" onClick={() => setView("auth")}>
        <span className="brand-dot" />
        Device Auth
      </div>
      <div className="topbar-actions">
        {showHelpToggle && view === "auth" && (
          <button
            className="btn-ghost"
            onClick={() => setShowDirectFetch((s) => !s)}
          >
            <Radar size={14} />
            {showDirectFetch ? "Hide direct fetch" : "Direct IP / MAC fetch"}
          </button>
        )}
        <button
          className="btn-ghost"
          onClick={() => setView(view === "help" ? "auth" : "help")}
        >
          <HelpCircle size={14} />
          {view === "help" ? "Close help" : "How it works"}
        </button>
        <button
          className="btn-ghost icon-only"
          onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
          title="Toggle theme"
        >
          {theme === "dark" ? <Sun size={14} /> : <Moon size={14} />}
        </button>
      </div>
    </div>
  );

  const Shell = ({ children }) => (
    <div className="page">
      <BackgroundFx />
      {children}
      <ToastContainer toasts={toasts} dismissToast={dismissToast} />
    </div>
  );

  if (view === "help") {
    return (
      <Shell>
        <TopBar showHelpToggle={false} />
        <HelpPage onBack={() => setView("auth")} />
        <Footer />
      </Shell>
    );
  }

  if (token) {
    return (
      <Shell>
        <TopBar />
        <div className="center-area">
          <div className="card fade-in">
            <div className="status-badge success">
              <ShieldCheck size={13} />
              Authenticated
            </div>
            <h2>Welcome back</h2>
            <p className="welcome-text">
              Logged in as <strong>{identifier}</strong>
              <span className={`chip chip-${identifierType?.toLowerCase()}`}>
                {identifierType}
              </span>
            </p>
            {hostname && <p className="hint">Hostname: {hostname}</p>}
            {expiresAt && (
              <SessionCountdown expiresAt={expiresAt} onExpire={handleExpire} />
            )}
            <button
              className="btn btn-secondary"
              onClick={() => {
                setToken("");
                showToast("Logged out", "info", 1800);
              }}
            >
              <LogOut size={14} />
              Log out
            </button>
          </div>
        </div>
        <Footer />
      </Shell>
    );
  }

  return (
    <Shell>
      <TopBar />

      <div className="center-area">
        {showDirectFetch && (
          <div className="card direct-fetch-card fade-in">
            <h3>Direct Fetch</h3>
            <p className="hint">
              Query the server for the raw IP or MAC address on demand,
              independent of the auto-detected login identifier below.
            </p>

            <div className="direct-fetch-row">
              <div className="direct-fetch-result">
                <span className="field-label">IP Address</span>
                <span className="mono-value">
                  {directIpLoading ? "Fetching…" : directIp || "—"}
                  <CopyButton value={directIp} onToast={showToast} />
                </span>
              </div>
              <button
                className="btn btn-small"
                onClick={handleFetchIp}
                disabled={directIpLoading}
              >
                {directIpLoading ? "Fetching…" : "Fetch IP"}
              </button>
            </div>

            <div className="direct-fetch-row">
              <div className="direct-fetch-result">
                <span className="field-label">MAC Address</span>
                <span className="mono-value">
                  {directMacLoading ? "Fetching…" : directMac || "—"}
                  <CopyButton value={directMac} onToast={showToast} />
                </span>
                {directMacError && (
                  <span className="error small">{directMacError}</span>
                )}
              </div>
              <button
                className="btn btn-small"
                onClick={handleFetchMac}
                disabled={directMacLoading}
              >
                {directMacLoading ? "Fetching…" : "Fetch MAC"}
              </button>
            </div>
            <p className="hint tiny">
              MAC lookup only resolves on the same LAN/subnet as the server
              (ARP table). Over the public internet it will return an error —
              that's expected, not a bug.
            </p>
          </div>
        )}

        <div className="card fade-in">
          <div className="mode-toggle">
            <button
              className={mode === "login" ? "toggle-btn active" : "toggle-btn"}
              onClick={() => setMode("login")}
            >
              Log In
            </button>
            <button
              className={mode === "register" ? "toggle-btn active" : "toggle-btn"}
              onClick={() => setMode("register")}
            >
              Register
            </button>
          </div>

          <label className="field-label">
            Username (auto-detected)
            <button
              className="refresh-btn"
              title="Re-detect device identity"
              onClick={loadIdentity}
              type="button"
            >
              ⟳
            </button>
          </label>
          <div className="readonly-input-row">
            <input
              className={`readonly-input${loadingDevice ? " skeleton" : ""}`}
              type="text"
              value={loadingDevice ? "Detecting device..." : identifier}
              readOnly
            />
            <CopyButton value={identifier} onToast={showToast} />
          </div>
          <div className="meta-row">
            {identifierType && (
              <span className={`chip chip-${identifierType.toLowerCase()}`}>
                {identifierType}
              </span>
            )}
            {hostname && <span className="hint">{hostname}</span>}
          </div>
          {deviceError && <p className="error">{deviceError}</p>}

          {mode === "login" ? (
            <LoginForm onSuccess={handleAuthSuccess} onToast={showToast} />
          ) : (
            <RegisterForm onSuccess={handleAuthSuccess} onToast={showToast} />
          )}
        </div>
      </div>

      <Footer />
    </Shell>
  );
}

export default App;
