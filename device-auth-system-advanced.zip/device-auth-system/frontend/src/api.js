import axios from "axios";

const API_BASE_URL = process.env.REACT_APP_API_BASE_URL || "http://localhost:8080/api";

const api = axios.create({
  baseURL: API_BASE_URL,
});

export const getDeviceIdentity = () => api.get("/device/identify");

export const fetchIpDirect = () => api.get("/device/ip");

export const fetchMacDirect = () => api.get("/device/mac");

export const registerUser = (password) => api.post("/auth/register", { password });

export const loginUser = (password) => api.post("/auth/login", { password });

export default api;
