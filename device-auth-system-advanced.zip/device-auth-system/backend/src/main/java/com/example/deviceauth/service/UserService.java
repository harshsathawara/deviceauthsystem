package com.example.deviceauth.service;

import com.example.deviceauth.dto.DeviceIdentity;
import com.example.deviceauth.model.AppUser;
import com.example.deviceauth.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class UserService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    public AppUser register(DeviceIdentity identity, String rawPassword) {
        if (userRepository.existsByIdentifier(identity.getIdentifier())) {
            throw new IllegalStateException(
                    "An account already exists for this device (" + identity.getIdentifier() + ")");
        }
        AppUser user = AppUser.builder()
                .identifier(identity.getIdentifier())
                .identifierType(identity.getIdentifierType())
                .passwordHash(passwordEncoder.encode(rawPassword))
                .build();
        return userRepository.save(user);
    }

    public AppUser login(DeviceIdentity identity, String rawPassword) {
        AppUser user = userRepository.findByIdentifier(identity.getIdentifier())
                .orElseThrow(() -> new IllegalStateException(
                        "No account found for this device (" + identity.getIdentifier() + "). Please register first."));

        if (!passwordEncoder.matches(rawPassword, user.getPasswordHash())) {
            throw new IllegalStateException("Incorrect password");
        }
        return user;
    }
}
