package com.example.deviceauth.controller;

import com.example.deviceauth.dto.AuthRequest;
import com.example.deviceauth.dto.AuthResponse;
import com.example.deviceauth.dto.DeviceIdentity;
import com.example.deviceauth.model.AppUser;
import com.example.deviceauth.service.DeviceIdentityService;
import com.example.deviceauth.service.LoginRateLimiter;
import com.example.deviceauth.service.UserService;
import com.example.deviceauth.util.JwtUtil;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
public class AuthController {

    private static final Logger log = LoggerFactory.getLogger(AuthController.class);

    private final DeviceIdentityService deviceIdentityService;
    private final UserService userService;
    private final JwtUtil jwtUtil;
    private final LoginRateLimiter rateLimiter;

    @PostMapping("/register")
    public ResponseEntity<?> register(@Valid @RequestBody AuthRequest req, HttpServletRequest request) {
        DeviceIdentity identity = deviceIdentityService.resolve(request);
        try {
            AppUser user = userService.register(identity, req.getPassword());
            String token = jwtUtil.generateToken(user.getIdentifier());
            log.info("Registered new device account: {} ({})", user.getIdentifier(), user.getIdentifierType());
            return ResponseEntity.ok(buildResponse(user, token, "Registered successfully"));
        } catch (IllegalStateException e) {
            log.warn("Registration failed for {}: {}", identity.getIdentifier(), e.getMessage());
            return ResponseEntity.status(HttpStatus.CONFLICT).body(errorBody(e.getMessage()));
        }
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@Valid @RequestBody AuthRequest req, HttpServletRequest request) {
        DeviceIdentity identity = deviceIdentityService.resolve(request);

        if (rateLimiter.isLocked(identity.getIdentifier())) {
            log.warn("Login blocked (rate limited) for {}", identity.getIdentifier());
            return ResponseEntity.status(HttpStatus.TOO_MANY_REQUESTS).body(errorBody(
                    "Too many failed attempts. Try again in " +
                            rateLimiter.secondsRemaining(identity.getIdentifier()) + "s."));
        }

        try {
            AppUser user = userService.login(identity, req.getPassword());
            rateLimiter.recordSuccess(identity.getIdentifier());
            String token = jwtUtil.generateToken(user.getIdentifier());
            log.info("Login success: {} ({})", user.getIdentifier(), user.getIdentifierType());
            return ResponseEntity.ok(buildResponse(user, token, "Login successful"));
        } catch (IllegalStateException e) {
            rateLimiter.recordFailure(identity.getIdentifier());
            log.warn("Login failed for {}: {}", identity.getIdentifier(), e.getMessage());
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(errorBody(e.getMessage()));
        }
    }

    private AuthResponse buildResponse(AppUser user, String token, String message) {
        long expiresAt = System.currentTimeMillis() + jwtUtil.getExpirationMs();
        return new AuthResponse(user.getIdentifier(), user.getIdentifierType(), token, message, expiresAt);
    }

    private Object errorBody(String message) {
        return new Object() {
            public final String error = message;
        };
    }
}
