package com.example.deviceauth.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class DeviceIdentity {
    /** The value to use as the username - MAC if resolved, else IP. */
    private String identifier;
    /** "MAC" or "IP" */
    private String identifierType;
    /** The raw client IP, always included for reference/debugging. */
    private String ipAddress;
    /** The raw MAC, if resolvable, regardless of which one became the identifier. */
    private String macAddress;
    /** Best-effort reverse-DNS hostname for the client IP, if resolvable. */
    private String hostname;
}
