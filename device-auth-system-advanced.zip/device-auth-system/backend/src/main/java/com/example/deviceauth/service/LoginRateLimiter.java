package com.example.deviceauth.service;

import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Very small in-memory brute-force guard, keyed by device identifier.
 * Not a substitute for a real distributed rate limiter (e.g. Redis-backed)
 * in a multi-instance deployment, but enough to slow down naive password
 * guessing against a single device's account.
 */
@Component
public class LoginRateLimiter {

    private static final int MAX_ATTEMPTS = 5;
    private static final long LOCKOUT_SECONDS = 60;

    private final ConcurrentHashMap<String, AtomicInteger> failedAttempts = new ConcurrentHashMap<>();
    private final ConcurrentHashMap<String, Instant> lockedUntil = new ConcurrentHashMap<>();

    public boolean isLocked(String identifier) {
        Instant until = lockedUntil.get(identifier);
        if (until == null) return false;
        if (Instant.now().isAfter(until)) {
            lockedUntil.remove(identifier);
            failedAttempts.remove(identifier);
            return false;
        }
        return true;
    }

    public long secondsRemaining(String identifier) {
        Instant until = lockedUntil.get(identifier);
        if (until == null) return 0;
        long remaining = until.getEpochSecond() - Instant.now().getEpochSecond();
        return Math.max(remaining, 0);
    }

    public void recordFailure(String identifier) {
        int attempts = failedAttempts.computeIfAbsent(identifier, k -> new AtomicInteger(0)).incrementAndGet();
        if (attempts >= MAX_ATTEMPTS) {
            lockedUntil.put(identifier, Instant.now().plusSeconds(LOCKOUT_SECONDS));
        }
    }

    public void recordSuccess(String identifier) {
        failedAttempts.remove(identifier);
        lockedUntil.remove(identifier);
    }
}
