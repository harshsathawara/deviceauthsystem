package com.example.deviceauth.controller;

import com.example.deviceauth.dto.DeviceIdentity;
import com.example.deviceauth.service.DeviceIdentityService;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
@RequestMapping("/api/device")
@RequiredArgsConstructor
public class DeviceController {

    private final DeviceIdentityService deviceIdentityService;

    /**
     * Called by the frontend on page load to populate the readonly
     * "username" field with the server-detected MAC (or IP fallback).
     * Also returns the raw IP, raw MAC (if any) and reverse-DNS hostname.
     */
    @GetMapping("/identify")
    public DeviceIdentity identify(HttpServletRequest request) {
        return deviceIdentityService.resolve(request);
    }

    /** Direct fetch: caller's IP address only, always available. */
    @GetMapping("/ip")
    public ResponseEntity<Map<String, String>> fetchIp(HttpServletRequest request) {
        String ip = deviceIdentityService.resolveIpOnly(request);
        return ResponseEntity.ok(Map.of("ipAddress", ip));
    }

    /**
     * Direct fetch: caller's MAC address via ARP lookup only.
     * Only resolves when the server and client share a LAN/subnet -
     * returns 404 with an explanatory message otherwise (e.g. over the public internet).
     */
    @GetMapping("/mac")
    public ResponseEntity<Map<String, String>> fetchMac(HttpServletRequest request) {
        String mac = deviceIdentityService.resolveMacOnly(request);
        if (mac == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(Map.of(
                    "error", "MAC address could not be resolved. This only works when the " +
                            "server and client are on the same local network (ARP lookup)."
            ));
        }
        return ResponseEntity.ok(Map.of("macAddress", mac));
    }
}
