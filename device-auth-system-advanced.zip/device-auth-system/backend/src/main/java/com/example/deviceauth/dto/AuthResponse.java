package com.example.deviceauth.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class AuthResponse {
    private String identifier;
    private String identifierType;
    private String token;
    private String message;
    /** Epoch millis when the JWT expires — lets the client show a session countdown. */
    private long expiresAt;
}
