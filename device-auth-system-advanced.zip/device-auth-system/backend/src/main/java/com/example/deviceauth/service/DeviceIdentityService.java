package com.example.deviceauth.service;

import com.example.deviceauth.dto.DeviceIdentity;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.stereotype.Service;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Resolves a "unique-enough" identifier for the calling device.
 *
 * IMPORTANT LIMITATION (read this before relying on this in production):
 * Browsers never expose a device's MAC address to JavaScript / HTTP requests,
 * so there is no way for the frontend to "know" the MAC address. The only way
 * a server can learn it is by looking up the caller's IP address in the local
 * network's ARP table - and that ONLY works when the server and the client
 * are on the same LAN/subnet (e.g. an office intranet app or a kiosk). Over
 * the public internet, or across routers/VPNs, this will never resolve and
 * the code automatically falls back to using the IP address instead.
 *
 * IP addresses are not perfectly stable either (DHCP leases change, multiple
 * devices can share a public IP behind NAT), but they're the best
 * browser-compatible fallback available.
 */
@Service
public class DeviceIdentityService {

    private static final Pattern ARP_LINE_LINUX =
            Pattern.compile("^(\\S+)\\s+0x\\d+\\s+0x\\d+\\s+([0-9a-fA-F:]{17})\\s+");

    private static final Pattern ARP_LINE_GENERIC_MAC =
            Pattern.compile("([0-9a-fA-F]{2}([:-][0-9a-fA-F]{2}){5})");

    public DeviceIdentity resolve(HttpServletRequest request) {
        String ip = extractClientIp(request);
        String mac = tryResolveMac(ip);
        String hostname = tryResolveHostname(ip);
        String normalizedMac = (mac != null && !mac.isBlank()) ? normalizeMac(mac) : null;

        if (normalizedMac != null) {
            return new DeviceIdentity(normalizedMac, "MAC", ip, normalizedMac, hostname);
        }
        return new DeviceIdentity(ip, "IP", ip, null, hostname);
    }

    /** Direct fetch: just the caller's IP address, no MAC/ARP lookup involved. */
    public String resolveIpOnly(HttpServletRequest request) {
        return extractClientIp(request);
    }

    /** Direct fetch: attempt an ARP-table MAC lookup for the caller's IP, same-LAN only. */
    public String resolveMacOnly(HttpServletRequest request) {
        String ip = extractClientIp(request);
        String mac = tryResolveMac(ip);
        return mac != null && !mac.isBlank() ? normalizeMac(mac) : null;
    }

    private String tryResolveHostname(String ip) {
        if (ip == null || ip.isBlank()) return null;
        try {
            java.net.InetAddress addr = java.net.InetAddress.getByName(ip);
            String host = addr.getCanonicalHostName();
            // getCanonicalHostName() silently falls back to the IP itself when reverse DNS fails
            return host.equals(ip) ? null : host;
        } catch (Exception e) {
            return null;
        }
    }

    /** Honors X-Forwarded-For when the app sits behind a reverse proxy. */
    private String extractClientIp(HttpServletRequest request) {
        String forwarded = request.getHeader("X-Forwarded-For");
        if (forwarded != null && !forwarded.isBlank()) {
            return forwarded.split(",")[0].trim();
        }
        String realIp = request.getHeader("X-Real-IP");
        if (realIp != null && !realIp.isBlank()) {
            return realIp.trim();
        }
        String remote = request.getRemoteAddr();
        // Normalize local loopback for readability during local dev
        if ("0:0:0:0:0:0:0:1".equals(remote)) {
            return "127.0.0.1";
        }
        return remote;
    }

    private String tryResolveMac(String ip) {
        if (ip == null || ip.isBlank() || "127.0.0.1".equals(ip)) {
            return null;
        }
        String mac = tryReadProcNetArp(ip);
        if (mac != null) return mac;

        return tryArpCommand(ip);
    }

    /** Linux: /proc/net/arp has columns: IP HW-type Flags MAC Mask Device */
    private String tryReadProcNetArp(String ip) {
        Path arpFile = Path.of("/proc/net/arp");
        if (!Files.exists(arpFile)) {
            return null;
        }
        try {
            List<String> lines = Files.readAllLines(arpFile, StandardCharsets.UTF_8);
            for (String line : lines) {
                String[] cols = line.trim().split("\\s+");
                if (cols.length >= 4 && cols[0].equals(ip)) {
                    String mac = cols[3];
                    if (!"00:00:00:00:00:00".equalsIgnoreCase(mac)) {
                        return mac;
                    }
                }
            }
        } catch (IOException ignored) {
            // fall through to null
        }
        return null;
    }

    /** Cross-platform fallback: shell out to `arp -a <ip>` or `arp -n <ip>`. */
    private String tryArpCommand(String ip) {
        String[][] candidateCommands = {
                {"arp", "-n", ip},
                {"arp", "-a", ip}
        };
        for (String[] cmd : candidateCommands) {
            try {
                Process process = new ProcessBuilder(cmd).redirectErrorStream(true).start();
                StringBuilder output = new StringBuilder();
                try (BufferedReader reader = new BufferedReader(
                        new InputStreamReader(process.getInputStream(), StandardCharsets.UTF_8))) {
                    String line;
                    while ((line = reader.readLine()) != null) {
                        output.append(line).append('\n');
                    }
                }
                process.waitFor();
                Matcher m = ARP_LINE_GENERIC_MAC.matcher(output.toString());
                if (m.find()) {
                    return m.group(1);
                }
            } catch (IOException | InterruptedException ignored) {
                // try next command / give up
            }
        }
        return null;
    }

    private String normalizeMac(String mac) {
        return mac.replace('-', ':').toUpperCase();
    }
}
