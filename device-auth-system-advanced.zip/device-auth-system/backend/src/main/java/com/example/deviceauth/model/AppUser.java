package com.example.deviceauth.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

@Entity
@Table(name = "app_users", uniqueConstraints = {
        @UniqueConstraint(columnNames = "identifier")
})
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AppUser {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /**
     * The MAC address (preferred) or IP address (fallback) of the device,
     * detected server-side. This doubles as the username and is never
     * trusted from client input.
     */
    @Column(nullable = false, unique = true, length = 64)
    private String identifier;

    /**
     * "MAC" or "IP" - tells you which kind of identifier was stored.
     */
    @Column(nullable = false, length = 8)
    private String identifierType;

    @Column(nullable = false)
    private String passwordHash;

    @Column(nullable = false, updatable = false)
    private LocalDateTime createdAt;

    @PrePersist
    protected void onCreate() {
        this.createdAt = LocalDateTime.now();
    }
}
