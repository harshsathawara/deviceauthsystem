# Device Identity Login System

A login system where the **username is auto-detected by the server** (MAC
address if resolvable, otherwise the device's IP address) and shown as a
**readonly field** on the frontend. The user only sets/enters a password.

- **Frontend:** React (Create React App style)
- **Backend:** Java Spring Boot 3 + Spring Security + JWT
- **Database:** PostgreSQL

---

## ⚠️ Important: read this about MAC addresses

Browsers **never** expose a device's MAC address to JavaScript — there is no
web API for it, on any browser, for privacy/security reasons. So the
frontend cannot "read" the MAC itself.

To get as close as possible to your request, the **backend** does the
detection instead:

1. It gets the caller's **IP address** from the HTTP request.
2. It attempts to resolve the corresponding **MAC address** by looking that
   IP up in the local network's **ARP table** (`/proc/net/arp` on Linux, or
   the `arp` command as a fallback on other OSes).
3. If a MAC is found → it's used as the username (`identifierType = "MAC"`).
4. If not → it falls back to the IP address (`identifierType = "IP"`).

**This ARP-based MAC lookup only works when the server and the client are on
the same local network/subnet** (e.g. an office intranet app, or a kiosk PC
talking to a local server). Over the public internet, through Wi-Fi
routers/NAT, or across VPNs, ARP lookups will not resolve, and the system
will automatically and transparently use the IP address instead — the app
still works either way, it's just less "MAC-specific" outside a LAN.

The identifier is **always determined server-side**, never sent by the
frontend — so it can't be spoofed by editing the browser request.

---

## Project structure

```
device-auth-system/
├── backend/     Spring Boot app (Maven)
└── frontend/    React app
```

---

## 1. Database setup (PostgreSQL)

Create the database (name it exactly this, or change it in
`application.properties`):

```sql
CREATE DATABASE device_auth_db;
```

Tables are created automatically by Hibernate (`ddl-auto=update`) on first
run — no manual schema needed. It creates one table: `app_users`.

---

## 2. Backend setup

Edit `backend/src/main/resources/application.properties`:

```properties
spring.datasource.url=jdbc:postgresql://localhost:5432/device_auth_db
spring.datasource.username=postgres
spring.datasource.password=postgres   # change to your actual password
app.jwt.secret=ChangeThisToALongRandomSecretKeyAtLeast32CharsLong!!
```

Run it:

```bash
cd backend
mvn spring-boot:run
```

Backend starts on **http://localhost:8080**.

### API endpoints

| Method | Endpoint                | Body                     | Notes                                                                 |
|--------|--------------------------|---------------------------|------------------------------------------------------------------------|
| GET    | `/api/device/identify`   | –                         | Returns `{identifier, identifierType, ipAddress, macAddress, hostname}` |
| GET    | `/api/device/ip`         | –                         | Direct fetch: `{ipAddress}` only, no ARP lookup                       |
| GET    | `/api/device/mac`        | –                         | Direct fetch: `{macAddress}`, or 404 if not resolvable (not same LAN) |
| POST   | `/api/auth/register`     | `{ "password": "..." }`   | Registers current device                                              |
| POST   | `/api/auth/login`        | `{ "password": "..." }`   | Logs in, returns JWT. Locks out after 5 failed attempts for 60s       |

### What's new in this version

- **Direct fetch endpoints** (`/api/device/ip`, `/api/device/mac`) — query the
  raw IP or MAC independently of the combined `/identify` call, exposed in
  the UI via a "Direct IP / MAC fetch" panel.
- **Reverse-DNS hostname** resolution added to `/api/device/identify`.
- **Login rate limiting** — an in-memory guard locks out an identifier for
  60 seconds after 5 failed password attempts (see `LoginRateLimiter`).
- **Consistent JSON error responses** via a global `@RestControllerAdvice`
  exception handler.
- **Reworked UI** — top bar, mode toggle, password show/hide, a password
  strength meter on registration, and a footer credit.
- **Help / "How it works" page** — animated hero, a 5-step flow timeline,
  use-case cards, a Direct Fetch explainer, and a security badge row.
- **Dark/light theme toggle**, animated gradient background, and toast
  notifications for login/register/copy/session events.
- **Copy-to-clipboard** buttons on the identifier field and direct-fetch
  results.
- **Session countdown** — login/register responses now include `expiresAt`;
  the UI shows a live countdown and auto-logs-out when the JWT expires.
- **Security headers filter** (`X-Content-Type-Options`, `X-Frame-Options`,
  `Referrer-Policy`, `Permissions-Policy`) and structured SLF4J logging of
  register/login attempts on the backend.

---

## 3. Frontend setup

```bash
cd frontend
npm install
npm start
```

Frontend starts on **http://localhost:3000** and talks to the backend at
`http://localhost:8080/api` (configurable via `REACT_APP_API_BASE_URL`).

---

## How it works

1. On page load, the frontend calls `GET /api/device/identify`.
2. The backend resolves the caller's MAC (via ARP) or falls back to IP, and
   returns it.
3. The frontend shows that value in a **readonly** "Username" input.
4. The user types a password and clicks **Register** (first time) or
   **Log In**.
5. The backend hashes/verifies the password with BCrypt and, on success,
   returns a JWT the frontend can use for subsequent authenticated calls.

---

## Notes / things you may want to change

- **JWT secret**: change `app.jwt.secret` before using this for anything
  real.
- **CORS origin**: set in `app.cors.allowed-origin` if your frontend runs
  somewhere other than `localhost:3000`.
- **One account per device**: since the identifier is unique in the DB, each
  detected MAC/IP can only register once. If you need multiple users per
  device, you'd add a separate username field instead of relying solely on
  MAC/IP.
- Running the backend on a machine that's NOT on the same LAN as your
  clients means it will always fall back to IP-based identification — this
  is expected, not a bug.
